--
-- Table structure for table `isco`
--

CREATE TABLE IF NOT EXISTS `isco` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9335 ;