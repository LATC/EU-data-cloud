<?php

$JOBS_DIR = 'file:///Users/anja/Projects/eures/jobs/';
$DIR = '/Users/anja/Projects/latc/EU-data-cloud/business/eures/import/';

$MYSQL_SERVER = '127.0.0.1';
$MYSQL_USER = 'anja';
$MYSQL_PASSWORD = 'danmark';
$MYSQL_DATABASE = 'eures';
