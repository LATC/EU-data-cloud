--
-- Table structure for table `language`
--

CREATE TABLE IF NOT EXISTS `language` (
  `iso639p3` varchar(3) DEFAULT NULL,
  `iso639p1` varchar(2) DEFAULT NULL,
  `labels` TEXT NOT NULL,
  PRIMARY KEY (`iso639p3`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
