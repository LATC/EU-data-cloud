--
-- Table structure for table `language`
--

CREATE TABLE IF NOT EXISTS `language` (
  `iso639p3` varchar(3) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
